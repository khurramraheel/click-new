const config = {
  google: {
    clientId:
      "302877729005-8sjfr0a8ehjcmbgft7nljq3slvss7f8d.apps.googleusercontent.com",
    clientSecret: "k7EVSRtORG6DJujYEcX6TMnp",
    refreshToken: "1/klJxkj4oJeg43jbvkc4Ckruve9HXhX-0WgdiDj0FGzM",
    redirectUri: "https://developers.google.com/oauthplayground"
  }
};
module.exports = config;
