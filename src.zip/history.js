import { createBrowserHistory } from 'history';

let myHistory = createBrowserHistory();

export default myHistory;